# coding=utf-8


if __name__ == '__main__':
    print('11111')
